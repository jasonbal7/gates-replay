the replay player is windows only
extract everything to the same folder first
run GatesOfOlympus_2500x_replay.exe
if windows warns you: more info -> run anyway
